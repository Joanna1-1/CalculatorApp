package com.example.calculatorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //Defining instance variables
    EditText editTextNumber1, editTextNumber2;
    TextView textViewOutput;
    Button buttonADD;
    Button buttonSUB;
    Button buttonMULT;
    Button buttonDIV;

    //Local variable
    int num1, num2, result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Setting up references for the view defined in the layout file
        editTextNumber1 = (EditText) findViewById(R.id.editTextNumber1);
        editTextNumber2 = (EditText) findViewById(R.id.editTextNumber2);
        buttonADD = (Button) findViewById(R.id.buttonADD);
        buttonSUB = (Button) findViewById(R.id.buttonSUB);
        buttonMULT = (Button) findViewById(R.id.buttonMULT);
        buttonDIV = (Button) findViewById(R.id.buttonDIV);
        textViewOutput = (TextView) findViewById(R.id.textViewOutput);
    }//end method

    public void btnADD_OnClick(View view){
        num1 = Integer.parseInt(editTextNumber1.getText().toString());
        num2 = Integer.parseInt(editTextNumber2.getText().toString());
        result = num1 + num2;
        textViewOutput.setText("SUM of input values: " + String.valueOf(result));//Displayed tge output using TextView - similar to label in other language
        //Toast.makeText(getApplicationContext(), "Sum: " + String.valueOf(result), Toast.LENGTH_SHORT).show(); //Similar to Messagebox or showdialog (can use this one)
        //Toast.makeText(getApplicationContext(), "Number 1: " + String.valueOf(num1) + "\nNumber 2: " + String.valueOf(num2) + "\nSum: " + String.valueOf(result), Toast.LENGTH_SHORT).show(); //Similar to Messagebox or showdialog (or this one
        Toast.makeText(this,"Number 1: " + String.valueOf(num1) + "\nNumber 2: " + String.valueOf(num2) + "\nSum: " + String.valueOf(result), Toast.LENGTH_SHORT).show(); //Similar to Messagebox or showdialog (or this one)
    }//end  method

    public void btnSUB_OnClick(View view){
        num1 = Integer.parseInt(editTextNumber1.getText().toString());
        num2 = Integer.parseInt(editTextNumber2.getText().toString());
        result = num1 - num2;
        textViewOutput.setText("SUM of input values: " + String.valueOf(result));//Displayed tge output using TextView - similar to label in other language
        Toast.makeText(this, "Number 1: " + String.valueOf(num1) + "\nNumber 2: " + String.valueOf(num2) + "\nsum: " + String.valueOf(result), Toast.LENGTH_SHORT).show();
    }//end method

    public void btnMULT_OnClick(View view){
        num1 = Integer.parseInt(editTextNumber1.getText().toString());
        num2 = Integer.parseInt(editTextNumber2.getText().toString());
        result = num1 * num2;
        textViewOutput.setText("SUM of input values: " + String.valueOf(result));//Displayed tge output using TextView - similar to label in other language
        Toast.makeText(this, "Number 1: " + String.valueOf(num1) + "\nNumber 2: " + String.valueOf(num2) + "\nSum: " + String.valueOf(result), Toast.LENGTH_SHORT).show();
    }//end method

    public void btnDIV_onClick(View view) {
        num1 = Integer.parseInt(editTextNumber1.getText().toString());
        num2 = Integer.parseInt(editTextNumber2.getText().toString());
        result = num1 / num2;
        textViewOutput.setText("SUM of input values: " + String.valueOf(result));//Displayed tge output using TextView - similar to label in other language
        Toast.makeText(this, "Number 1: " + String.valueOf(num1) + "\nNumber 2: " + String.valueOf(num2) + "\nSum: " + String.valueOf(result), Toast.LENGTH_SHORT).show();
    }//end method
}//end class